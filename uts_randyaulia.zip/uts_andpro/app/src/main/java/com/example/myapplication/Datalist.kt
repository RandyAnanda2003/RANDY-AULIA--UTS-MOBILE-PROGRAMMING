package com.example.myapplication

class Datalist (var npm: String, var nama: String ) {


}