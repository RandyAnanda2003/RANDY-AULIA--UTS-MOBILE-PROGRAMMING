package com.example.myapplication

data class Berita(var titleImage: Int, var heading: String, var deskripsi: String )
